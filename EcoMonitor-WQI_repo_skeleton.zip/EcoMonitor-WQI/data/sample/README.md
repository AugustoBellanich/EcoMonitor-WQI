# Data (sample)
Ubicá aquí datos anónimos o sintéticos para demostración.
Evitá publicar información sensible o geolocalizaciones exactas si no corresponde.

# Assets
Logos o imágenes opcionales (por ejemplo, `logo.png`, `em_logo.png`).
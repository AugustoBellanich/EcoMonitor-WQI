# Templates
Si necesitás plantillas predefinidas (umbrales por defecto, configuraciones), podés colocarlas aquí.
El notebook también puede **generarlas automáticamente** durante la ejecución.
